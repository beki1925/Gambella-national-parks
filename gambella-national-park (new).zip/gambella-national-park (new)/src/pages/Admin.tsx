import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Leaf, ArrowLeft, LogOut, ShieldCheck, Trash2, CheckCircle2, Crown, UserCog } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";

type Booking = { id: string; user_id: string; journey_name: string; start_date: string; party_size: number; contact_email: string; status: string; created_at: string };
type Sighting = { id: string; user_id: string; species: string; count: number | null; description: string | null; verified: boolean; observed_at: string };
type Donation = { id: string; donor_name: string | null; amount_usd: number; allocation: string; tx_hash: string | null; created_at: string };
type Subscriber = { id: string; email: string; created_at: string };
type Profile = { id: string; full_name: string | null; country: string | null };
type RoleRow = { id: string; user_id: string; role: "admin" | "ranger" | "visitor"; created_at: string };

const Admin = () => {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [userEmail, setUserEmail] = useState("");

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [sightings, setSightings] = useState<Sighting[]>([]);
  const [donations, setDonations] = useState<Donation[]>([]);
  const [subs, setSubs] = useState<Subscriber[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [roles, setRoles] = useState<RoleRow[]>([]);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      if (!session) navigate("/auth", { replace: true });
    });
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (!data.session) { navigate("/auth", { replace: true }); return; }
      setUserEmail(data.session.user.email ?? "");
      const { data: roleRows } = await supabase
        .from("user_roles").select("role").eq("user_id", data.session.user.id);
      const admin = (roleRows ?? []).some(r => r.role === "admin");
      setIsAdmin(admin);
      setChecking(false);
      if (admin) loadAll();
    })();
    return () => sub.subscription.unsubscribe();
  }, [navigate]);

  const loadAll = async () => {
    const [b, s, d, n, p, r] = await Promise.all([
      supabase.from("bookings").select("*").order("created_at", { ascending: false }),
      supabase.from("sightings").select("*").order("observed_at", { ascending: false }),
      supabase.from("donations").select("*").order("created_at", { ascending: false }),
      supabase.from("newsletter_subscribers").select("*").order("created_at", { ascending: false }),
      supabase.from("profiles").select("id, full_name, country"),
      supabase.from("user_roles").select("*").order("created_at", { ascending: false }),
    ]);
    setBookings((b.data ?? []) as Booking[]);
    setSightings((s.data ?? []) as Sighting[]);
    setDonations((d.data ?? []) as Donation[]);
    setSubs((n.data ?? []) as Subscriber[]);
    setProfiles((p.data ?? []) as Profile[]);
    setRoles((r.data ?? []) as RoleRow[]);
  };

  const claimAdmin = async () => {
    const { data, error } = await supabase.rpc("claim_admin_if_none");
    if (error) { toast({ title: "Failed", description: error.message, variant: "destructive" }); return; }
    if (data) {
      toast({ title: "You are now an admin" });
      setIsAdmin(true); loadAll();
    } else {
      toast({ title: "Admin already exists", description: "Ask an existing admin to grant your role.", variant: "destructive" });
    }
  };

  const setBookingStatus = async (id: string, status: string) => {
    const { error } = await supabase.from("bookings").update({ status }).eq("id", id);
    if (error) return toast({ title: "Update failed", description: error.message, variant: "destructive" });
    toast({ title: `Booking ${status}` }); loadAll();
  };
  const deleteBooking = async (id: string) => {
    const { error } = await supabase.from("bookings").delete().eq("id", id);
    if (error) return toast({ title: "Delete failed", description: error.message, variant: "destructive" });
    loadAll();
  };
  const verifySighting = async (id: string, verified: boolean) => {
    const { error } = await supabase.from("sightings").update({ verified }).eq("id", id);
    if (error) return toast({ title: "Update failed", description: error.message, variant: "destructive" });
    loadAll();
  };
  const deleteSighting = async (id: string) => {
    const { error } = await supabase.from("sightings").delete().eq("id", id);
    if (error) return toast({ title: "Delete failed", description: error.message, variant: "destructive" });
    loadAll();
  };
  const deleteDonation = async (id: string) => {
    const { error } = await supabase.from("donations").delete().eq("id", id);
    if (error) return toast({ title: "Delete failed", description: error.message, variant: "destructive" });
    loadAll();
  };
  const deleteSub = async (id: string) => {
    const { error } = await supabase.from("newsletter_subscribers").delete().eq("id", id);
    if (error) return toast({ title: "Delete failed", description: error.message, variant: "destructive" });
    loadAll();
  };
  const setUserRole = async (userId: string, role: "admin" | "ranger" | "visitor") => {
    // remove existing roles, add new
    await supabase.from("user_roles").delete().eq("user_id", userId);
    const { error } = await supabase.from("user_roles").insert({ user_id: userId, role });
    if (error) return toast({ title: "Role update failed", description: error.message, variant: "destructive" });
    toast({ title: `Role set to ${role}` }); loadAll();
  };

  const signOut = async () => { await supabase.auth.signOut(); navigate("/", { replace: true }); };

  if (checking) {
    return <main className="min-h-screen bg-ink text-background grid place-items-center font-mono text-xs">Verifying access…</main>;
  }

  if (!isAdmin) {
    return (
      <main className="min-h-screen bg-ink text-background grid place-items-center p-6">
        <Card className="bg-white/5 border-white/10 text-background max-w-md w-full">
          <CardHeader>
            <CardTitle className="font-display text-2xl flex items-center gap-2"><ShieldCheck className="w-5 h-5 text-gold" /> Admin access required</CardTitle>
            <CardDescription className="text-background/60">Signed in as {userEmail}. Only admins can manage the park.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="hero" className="w-full" onClick={claimAdmin}>
              <Crown className="w-4 h-4" /> Claim admin (first user only)
            </Button>
            <Button variant="ghostLight" className="w-full" asChild>
              <Link to="/"><ArrowLeft className="w-4 h-4" /> Back to park</Link>
            </Button>
          </CardContent>
        </Card>
      </main>
    );
  }

  const roleOf = (uid: string) => roles.find(r => r.user_id === uid)?.role ?? "visitor";

  return (
    <main className="min-h-screen bg-ink text-background">
      <header className="border-b border-white/10 sticky top-0 z-30 backdrop-blur bg-ink/80">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full gradient-gold grid place-items-center"><Leaf className="w-4 h-4 text-ink" /></div>
            <span className="font-display text-lg">Gambella<span className="text-gold">.</span></span>
            <Badge className="ml-2 bg-gold/20 text-gold border-gold/40" variant="outline">Admin</Badge>
          </Link>
          <div className="flex items-center gap-2">
            <Button variant="ghostLight" size="sm" asChild><Link to="/dashboard">My dashboard</Link></Button>
            <Button variant="ghostLight" size="sm" asChild><Link to="/"><ArrowLeft className="w-4 h-4" /> Park</Link></Button>
            <Button variant="ghostLight" size="sm" onClick={signOut}><LogOut className="w-4 h-4" /> Sign out</Button>
          </div>
        </div>
      </header>

      <section className="max-w-7xl mx-auto px-6 py-12">
        <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-gold mb-3">— Mission control</p>
        <h1 className="font-display text-5xl md:text-6xl font-light tracking-tight">Park <span className="italic text-gold">administration</span></h1>

        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4 mt-10">
          <StatCard label="Bookings" value={bookings.length} />
          <StatCard label="Sightings" value={sightings.length} />
          <StatCard label="Donations $" value={donations.reduce((s, d) => s + Number(d.amount_usd), 0).toLocaleString()} />
          <StatCard label="Subscribers" value={subs.length} />
          <StatCard label="Members" value={profiles.length} />
        </div>

        <Tabs defaultValue="bookings" className="mt-12">
          <TabsList className="bg-white/5 border border-white/10">
            <TabsTrigger value="bookings">Bookings</TabsTrigger>
            <TabsTrigger value="sightings">Sightings</TabsTrigger>
            <TabsTrigger value="donations">Donations</TabsTrigger>
            <TabsTrigger value="subscribers">Newsletter</TabsTrigger>
            <TabsTrigger value="users">Users & Roles</TabsTrigger>
          </TabsList>

          <TabsContent value="bookings" className="mt-6">
            <DataCard title="All reservations">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/10 hover:bg-transparent">
                    <TableHead className="text-background/60">Journey</TableHead>
                    <TableHead className="text-background/60">Date</TableHead>
                    <TableHead className="text-background/60">Party</TableHead>
                    <TableHead className="text-background/60">Email</TableHead>
                    <TableHead className="text-background/60">Status</TableHead>
                    <TableHead className="text-background/60 text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {bookings.map(b => (
                    <TableRow key={b.id} className="border-white/10">
                      <TableCell>{b.journey_name}</TableCell>
                      <TableCell className="font-mono text-xs">{new Date(b.start_date).toLocaleDateString()}</TableCell>
                      <TableCell>{b.party_size}</TableCell>
                      <TableCell className="font-mono text-xs">{b.contact_email}</TableCell>
                      <TableCell>
                        <Select value={b.status} onValueChange={v => setBookingStatus(b.id, v)}>
                          <SelectTrigger className="h-8 w-32 bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Pending</SelectItem>
                            <SelectItem value="confirmed">Confirmed</SelectItem>
                            <SelectItem value="cancelled">Cancelled</SelectItem>
                            <SelectItem value="completed">Completed</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button size="sm" variant="ghostLight" onClick={() => deleteBooking(b.id)}><Trash2 className="w-3.5 h-3.5" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {bookings.length === 0 && <Empty cols={6} />}
                </TableBody>
              </Table>
            </DataCard>
          </TabsContent>

          <TabsContent value="sightings" className="mt-6">
            <DataCard title="Wildlife sightings">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/10 hover:bg-transparent">
                    <TableHead className="text-background/60">Species</TableHead>
                    <TableHead className="text-background/60">Count</TableHead>
                    <TableHead className="text-background/60">Observed</TableHead>
                    <TableHead className="text-background/60">Verified</TableHead>
                    <TableHead className="text-background/60 text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sightings.map(s => (
                    <TableRow key={s.id} className="border-white/10">
                      <TableCell>{s.species}</TableCell>
                      <TableCell>{s.count ?? "—"}</TableCell>
                      <TableCell className="font-mono text-xs">{new Date(s.observed_at).toLocaleString()}</TableCell>
                      <TableCell>
                        {s.verified
                          ? <Badge className="bg-emerald/20 text-emerald border-emerald/40" variant="outline">Verified</Badge>
                          : <Badge className="bg-gold/20 text-gold border-gold/40" variant="outline">Pending</Badge>}
                      </TableCell>
                      <TableCell className="text-right space-x-2">
                        <Button size="sm" variant="ghostLight" onClick={() => verifySighting(s.id, !s.verified)}>
                          <CheckCircle2 className="w-3.5 h-3.5" /> {s.verified ? "Unverify" : "Verify"}
                        </Button>
                        <Button size="sm" variant="ghostLight" onClick={() => deleteSighting(s.id)}><Trash2 className="w-3.5 h-3.5" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {sightings.length === 0 && <Empty cols={5} />}
                </TableBody>
              </Table>
            </DataCard>
          </TabsContent>

          <TabsContent value="donations" className="mt-6">
            <DataCard title="Donations ledger">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/10 hover:bg-transparent">
                    <TableHead className="text-background/60">Donor</TableHead>
                    <TableHead className="text-background/60">Amount</TableHead>
                    <TableHead className="text-background/60">Allocation</TableHead>
                    <TableHead className="text-background/60">Date</TableHead>
                    <TableHead className="text-background/60 text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {donations.map(d => (
                    <TableRow key={d.id} className="border-white/10">
                      <TableCell>{d.donor_name ?? "Anonymous"}</TableCell>
                      <TableCell className="font-mono">${Number(d.amount_usd).toLocaleString()}</TableCell>
                      <TableCell>{d.allocation}</TableCell>
                      <TableCell className="font-mono text-xs">{new Date(d.created_at).toLocaleDateString()}</TableCell>
                      <TableCell className="text-right">
                        <Button size="sm" variant="ghostLight" onClick={() => deleteDonation(d.id)}><Trash2 className="w-3.5 h-3.5" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {donations.length === 0 && <Empty cols={5} />}
                </TableBody>
              </Table>
            </DataCard>
          </TabsContent>

          <TabsContent value="subscribers" className="mt-6">
            <DataCard title="Newsletter subscribers">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/10 hover:bg-transparent">
                    <TableHead className="text-background/60">Email</TableHead>
                    <TableHead className="text-background/60">Joined</TableHead>
                    <TableHead className="text-background/60 text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {subs.map(s => (
                    <TableRow key={s.id} className="border-white/10">
                      <TableCell className="font-mono text-xs">{s.email}</TableCell>
                      <TableCell className="font-mono text-xs">{new Date(s.created_at).toLocaleDateString()}</TableCell>
                      <TableCell className="text-right">
                        <Button size="sm" variant="ghostLight" onClick={() => deleteSub(s.id)}><Trash2 className="w-3.5 h-3.5" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {subs.length === 0 && <Empty cols={3} />}
                </TableBody>
              </Table>
            </DataCard>
          </TabsContent>

          <TabsContent value="users" className="mt-6">
            <DataCard title="Members & roles">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/10 hover:bg-transparent">
                    <TableHead className="text-background/60">Name</TableHead>
                    <TableHead className="text-background/60">Country</TableHead>
                    <TableHead className="text-background/60">Role</TableHead>
                    <TableHead className="text-background/60 text-right">Set role</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {profiles.map(p => (
                    <TableRow key={p.id} className="border-white/10">
                      <TableCell>{p.full_name ?? "—"}</TableCell>
                      <TableCell>{p.country ?? "—"}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-white/5 border-white/20 text-background/80 capitalize">
                          <UserCog className="w-3 h-3 mr-1" /> {roleOf(p.id)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Select value={roleOf(p.id)} onValueChange={v => setUserRole(p.id, v as any)}>
                          <SelectTrigger className="h-8 w-32 ml-auto bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="visitor">Visitor</SelectItem>
                            <SelectItem value="ranger">Ranger</SelectItem>
                            <SelectItem value="admin">Admin</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                    </TableRow>
                  ))}
                  {profiles.length === 0 && <Empty cols={4} />}
                </TableBody>
              </Table>
            </DataCard>
          </TabsContent>
        </Tabs>
      </section>
    </main>
  );
};

const StatCard = ({ label, value }: { label: string; value: string | number }) => (
  <Card className="bg-white/5 border-white/10 text-background">
    <CardHeader className="pb-2"><CardDescription className="text-background/60 font-mono text-[10px] uppercase tracking-widest">{label}</CardDescription></CardHeader>
    <CardContent><div className="font-display text-3xl">{value}</div></CardContent>
  </Card>
);

const DataCard = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <Card className="bg-white/5 border-white/10 text-background">
    <CardHeader><CardTitle className="font-display text-xl">{title}</CardTitle></CardHeader>
    <CardContent className="overflow-x-auto">{children}</CardContent>
  </Card>
);

const Empty = ({ cols }: { cols: number }) => (
  <TableRow className="border-white/10"><TableCell colSpan={cols} className="text-center text-background/50 font-mono text-xs py-10">No records yet.</TableCell></TableRow>
);

export default Admin;
