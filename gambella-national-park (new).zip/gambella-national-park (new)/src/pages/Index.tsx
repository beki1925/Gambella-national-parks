import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight, Bird, Leaf, MapPin, Radio, Sparkles, Waves, Wind, ChevronDown, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import type { User } from "@supabase/supabase-js";
import { BookingDialog } from "@/components/BookingDialog";
import { NewsletterForm } from "@/components/NewsletterForm";
import heroImg from "@/assets/hero-gambella.jpg";
import lechweImg from "@/assets/wildlife-lechwe.jpg";
import elephantsImg from "@/assets/wildlife-elephants.jpg";
import migrationImg from "@/assets/wildlife-migration.jpg";
import shoebillImg from "@/assets/wildlife-shoebill.jpg";

const Nav = () => {
  const [user, setUser] = useState<User | null>(null);
  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setUser(s?.user ?? null));
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user ?? null));
    return () => sub.subscription.unsubscribe();
  }, []);
  return (
    <nav className="fixed top-0 inset-x-0 z-50 backdrop-blur-md bg-ink/30 border-b border-white/10">
      <div className="max-w-[1600px] mx-auto px-6 lg:px-12 h-16 flex items-center justify-between">
        <a href="#" className="flex items-center gap-3 text-background">
          <div className="w-8 h-8 rounded-full gradient-gold grid place-items-center">
            <Leaf className="w-4 h-4 text-ink" />
          </div>
          <span className="font-display text-lg tracking-tight">Gambella<span className="text-gold">.</span></span>
        </a>
        <div className="hidden md:flex items-center gap-8 text-sm font-body text-background/80">
          <a href="#wild" className="hover:text-gold transition-colors">The Wild</a>
          <a href="#live" className="hover:text-gold transition-colors">Live Park</a>
          <a href="#ai" className="hover:text-gold transition-colors">AI Ranger</a>
          <a href="#journeys" className="hover:text-gold transition-colors">Journeys</a>
          <a href="#conserve" className="hover:text-gold transition-colors">Conserve</a>
        </div>
        {user ? (
          <Button variant="hero" size="sm" onClick={() => supabase.auth.signOut()}>
            Sign out <LogOut className="w-4 h-4" />
          </Button>
        ) : (
          <Button variant="hero" size="sm" asChild>
            <Link to="/auth">Sign in <ArrowUpRight className="w-4 h-4" /></Link>
          </Button>
        )}
      </div>
    </nav>
  );
};

const LiveTicker = () => {
  const items = [
    "12,400 white-eared kob tracked · last 24h",
    "Baro River · 27.4°C · flow normal",
    "3 elephant herds active · Akobo zone",
    "AI scan · 0 poaching alerts today",
    "Shoebill stork · sighted 06:42 EAT",
    "Canopy temp · 31.8°C · humidity 78%",
  ];
  return (
    <div className="overflow-hidden bg-ink text-background/70 border-y border-white/10">
      <div className="marquee py-3 font-mono text-xs uppercase tracking-widest whitespace-nowrap">
        {[...items, ...items].map((t, i) => (
          <span key={i} className="flex items-center gap-3 px-8 shrink-0">
            <span className="w-1.5 h-1.5 rounded-full bg-accent live-dot" />
            {t}
          </span>
        ))}
      </div>
    </div>
  );
};

const Hero = () => {
  const [time, setTime] = useState("");
  useEffect(() => {
    const update = () => {
      const now = new Date();
      const eat = new Date(now.getTime() + (3 * 60 - now.getTimezoneOffset()) * 60000);
      setTime(eat.toUTCString().slice(17, 22) + " EAT");
    };
    update();
    const id = setInterval(update, 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <section className="relative min-h-screen w-full overflow-hidden bg-ink">
      <img src={heroImg} alt="Aerial view of Gambella National Park wetlands at dawn" width={1920} height={1080}
        className="absolute inset-0 w-full h-full object-cover animate-ken-burns" />
      <div className="absolute inset-0 gradient-hero" />
      <div className="absolute inset-0 grain" />

      <div className="relative z-10 max-w-[1600px] mx-auto px-6 lg:px-12 pt-32 lg:pt-40 pb-12 min-h-screen flex flex-col">
        <div className="flex items-center gap-3 text-background/70 font-mono text-xs uppercase tracking-[0.25em] animate-float-up">
          <span className="w-2 h-2 rounded-full bg-accent live-dot" />
          Live · 8°15′N 34°35′E · {time}
        </div>

        <h1 className="mt-8 font-display font-light text-background text-[clamp(3rem,9vw,9.5rem)] leading-[0.9] tracking-tighter text-balance animate-float-up" style={{ animationDelay: "0.1s" }}>
          Where Africa<br />
          <span className="italic font-normal text-gold">still breathes</span><br />
          <span className="text-background/60">unwitnessed.</span>
        </h1>

        <p className="mt-10 max-w-xl text-background/80 font-body text-lg leading-relaxed animate-float-up" style={{ animationDelay: "0.3s" }}>
          5,061 square kilometres of pristine savanna, papyrus wetland and gallery forest in southwestern Ethiopia — home to the world's second-largest mammal migration and a frontier laboratory for AI-driven conservation.
        </p>

        <div className="mt-10 flex flex-wrap gap-4 animate-float-up" style={{ animationDelay: "0.5s" }}>
          <Button variant="hero" size="lg">Begin Expedition <ArrowUpRight className="w-4 h-4" /></Button>
          <Button variant="ghostLight" size="lg">Open Live Map</Button>
        </div>

        <div className="mt-auto pt-16 grid grid-cols-2 md:grid-cols-4 gap-8 border-t border-white/15 pt-10">
          {[
            ["5,061", "km² protected"],
            ["1.2M+", "kob in migration"],
            ["327", "bird species"],
            ["1973", "founded"],
          ].map(([k, v]) => (
            <div key={v} className="text-background animate-float-up" style={{ animationDelay: "0.7s" }}>
              <div className="font-display text-4xl lg:text-5xl font-light tracking-tight">{k}</div>
              <div className="font-mono text-xs uppercase tracking-widest text-background/60 mt-2">{v}</div>
            </div>
          ))}
        </div>

        <div className="absolute bottom-6 right-6 lg:right-12 text-background/50 flex items-center gap-2 text-xs font-mono uppercase tracking-widest">
          Scroll <ChevronDown className="w-3 h-3 animate-bounce" />
        </div>
      </div>
    </section>
  );
};

const WildSection = () => {
  const species = [
    { img: lechweImg, name: "Nile Lechwe", latin: "Kobus megaceros", tag: "Endemic · Endangered", desc: "The wetland-walker. Found nowhere else in Ethiopia." },
    { img: migrationImg, name: "White-eared Kob", latin: "Kobus kob leucotis", tag: "1.2M individuals", desc: "Architects of the great migration — a living river across the savanna." },
    { img: elephantsImg, name: "African Elephant", latin: "Loxodonta africana", tag: "Recovering population", desc: "Last refuge for elephants in western Ethiopia." },
    { img: shoebillImg, name: "Shoebill Stork", latin: "Balaeniceps rex", tag: "Rare · Iconic", desc: "Prehistoric silhouette of the Baro papyrus swamps." },
  ];
  return (
    <section id="wild" className="relative py-24 lg:py-40 bg-background">
      <div className="max-w-[1600px] mx-auto px-6 lg:px-12">
        <div className="flex items-end justify-between flex-wrap gap-8 mb-16">
          <div className="max-w-2xl">
            <div className="font-mono text-xs uppercase tracking-[0.25em] text-clay mb-6">— 01 / The Wild</div>
            <h2 className="font-display font-light text-foreground text-5xl lg:text-7xl leading-[0.95] tracking-tight text-balance">
              A megafauna sanctuary <span className="italic text-emerald">forgotten</span> by the modern world.
            </h2>
          </div>
          <p className="max-w-md font-body text-muted-foreground text-lg leading-relaxed">
            Gambella shelters species lost elsewhere on the continent — its inaccessibility has been its greatest protection. Now we open it, gently, to those who will help defend it.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {species.map((s, i) => (
            <article key={s.name} className="group relative overflow-hidden rounded-sm bg-card aspect-[3/4] cursor-pointer">
              <img src={s.img} alt={s.name} loading="lazy" width={800} height={1066}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-[1.4s] group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-transparent" />
              <div className="absolute top-4 left-4 right-4 flex justify-between text-background/80 font-mono text-[10px] uppercase tracking-widest">
                <span>0{i + 1}</span>
                <span>{s.tag}</span>
              </div>
              <div className="absolute bottom-0 inset-x-0 p-6 text-background">
                <div className="font-display text-2xl">{s.name}</div>
                <div className="font-mono text-xs italic text-background/60 mt-1">{s.latin}</div>
                <div className="text-sm text-background/80 mt-3 max-h-0 overflow-hidden group-hover:max-h-32 transition-all duration-500">
                  {s.desc}
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

const LiveDashboard = () => {
  const [data, setData] = useState({ temp: 27.4, herds: 12, birds: 84, alerts: 0 });
  useEffect(() => {
    const id = setInterval(() => {
      setData(d => ({
        temp: +(26 + Math.random() * 4).toFixed(1),
        herds: Math.floor(8 + Math.random() * 8),
        birds: Math.floor(70 + Math.random() * 30),
        alerts: Math.random() > 0.92 ? 1 : 0,
      }));
    }, 3000);
    return () => clearInterval(id);
  }, []);

  const tiles = [
    { icon: Waves, label: "Baro River temp", value: `${data.temp}°C`, sub: "12 sensors · normal flow" },
    { icon: Bird, label: "Active bird species", value: `${data.birds}`, sub: "Acoustic ID · last hour" },
    { icon: Wind, label: "Tracked herds", value: `${data.herds}`, sub: "Satellite collars" },
    { icon: Radio, label: "Poaching alerts", value: data.alerts ? "1 INVESTIGATING" : "All clear", sub: "AI thermal grid · 24h", danger: !!data.alerts },
  ];

  return (
    <section id="live" className="relative py-24 lg:py-40 bg-ink text-background overflow-hidden">
      <div className="absolute inset-0 gradient-mist opacity-40" />
      <div className="relative max-w-[1600px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-12 gap-12 mb-16">
          <div className="lg:col-span-7">
            <div className="font-mono text-xs uppercase tracking-[0.25em] text-gold mb-6">— 02 / Live Park</div>
            <h2 className="font-display font-light text-5xl lg:text-7xl leading-[0.95] tracking-tight text-balance">
              The park, <span className="italic text-gold">streamed</span> to your screen.
            </h2>
          </div>
          <p className="lg:col-span-5 lg:pt-24 font-body text-background/70 text-lg leading-relaxed">
            A network of solar IoT sensors, GPS collars, acoustic monitors and thermal drones broadcasts the heartbeat of Gambella in real time — open to scientists, donors, and the curious.
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-px bg-white/10 border border-white/10">
          {tiles.map((t) => (
            <div key={t.label} className="bg-ink p-6 lg:p-8 relative group hover:bg-white/[0.03] transition-colors">
              <div className="flex items-center justify-between mb-8">
                <t.icon className="w-5 h-5 text-gold" />
                <span className={`font-mono text-[10px] uppercase tracking-widest flex items-center gap-2 ${t.danger ? "text-destructive" : "text-background/50"}`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${t.danger ? "bg-destructive" : "bg-accent"} live-dot`} />
                  Live
                </span>
              </div>
              <div className={`font-display text-3xl lg:text-5xl font-light tracking-tight ${t.danger ? "text-destructive" : ""}`}>{t.value}</div>
              <div className="mt-3 font-mono text-[10px] uppercase tracking-widest text-background/50">{t.label}</div>
              <div className="mt-1 text-xs text-background/40">{t.sub}</div>
            </div>
          ))}
        </div>

        <div className="mt-px grid lg:grid-cols-3 gap-px bg-white/10 border-x border-b border-white/10">
          <div className="lg:col-span-2 bg-ink p-8 lg:p-12 relative overflow-hidden min-h-[360px]">
            <div className="font-mono text-[10px] uppercase tracking-widest text-background/50 mb-4">Migration corridor · last 7 days</div>
            <div className="absolute inset-x-8 bottom-8 top-20">
              <svg viewBox="0 0 600 200" className="w-full h-full" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="g" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor="hsl(var(--gold))" stopOpacity="0.8" />
                    <stop offset="100%" stopColor="hsl(var(--gold))" stopOpacity="0" />
                  </linearGradient>
                </defs>
                <path d="M0,160 C80,120 140,180 220,100 C300,40 360,140 440,80 C520,30 560,90 600,60 L600,200 L0,200 Z" fill="url(#g)" />
                <path d="M0,160 C80,120 140,180 220,100 C300,40 360,140 440,80 C520,30 560,90 600,60" fill="none" stroke="hsl(var(--gold))" strokeWidth="1.5" />
                {[0, 100, 200, 300, 400, 500, 600].map(x => (
                  <circle key={x} cx={x} cy={160 - Math.sin(x / 60) * 60} r="3" fill="hsl(var(--gold))" />
                ))}
              </svg>
            </div>
            <div className="absolute bottom-4 left-8 right-8 flex justify-between font-mono text-[10px] uppercase tracking-widest text-background/40">
              <span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span>
            </div>
          </div>
          <div className="bg-ink p-8 lg:p-12">
            <div className="font-mono text-[10px] uppercase tracking-widest text-background/50 mb-4">Today's expedition window</div>
            <div className="font-display text-2xl mb-6">Excellent</div>
            <ul className="space-y-3 text-sm text-background/70">
              <li className="flex justify-between border-b border-white/10 pb-3"><span>Visibility</span><span className="font-mono text-gold">9.2 km</span></li>
              <li className="flex justify-between border-b border-white/10 pb-3"><span>Wind</span><span className="font-mono text-gold">6 km/h SE</span></li>
              <li className="flex justify-between border-b border-white/10 pb-3"><span>Humidity</span><span className="font-mono text-gold">78%</span></li>
              <li className="flex justify-between"><span>Sighting score</span><span className="font-mono text-accent">94 / 100</span></li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

const AISection = () => (
  <section id="ai" className="relative py-24 lg:py-40 bg-background overflow-hidden">
    <div className="max-w-[1600px] mx-auto px-6 lg:px-12 grid lg:grid-cols-12 gap-12 items-center">
      <div className="lg:col-span-5">
        <div className="font-mono text-xs uppercase tracking-[0.25em] text-clay mb-6">— 03 / AI Ranger</div>
        <h2 className="font-display font-light text-5xl lg:text-7xl leading-[0.95] tracking-tight text-balance text-foreground">
          Your <span className="italic text-emerald">field guide</span>, trained on a decade of Gambella.
        </h2>
        <p className="mt-8 font-body text-muted-foreground text-lg leading-relaxed">
          Ask anything. The AI Ranger speaks Amharic, Anuak, Nuer and English — drawing from ranger logs, satellite imagery and live telemetry to answer with the depth of a senior naturalist.
        </p>
        <div className="mt-8 flex gap-4">
          <Button variant="emerald" size="lg">Talk to Ranger AI <Sparkles className="w-4 h-4" /></Button>
        </div>
      </div>

      <div className="lg:col-span-7 relative">
        <div className="rounded-sm border border-border bg-card shadow-elegant overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b border-border bg-muted/40">
            <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
              <span className="w-2 h-2 rounded-full bg-accent live-dot" />
              Ranger AI · online
            </div>
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">v3.2 · gambella-llm</span>
          </div>
          <div className="p-6 lg:p-8 space-y-5 text-sm">
            <div className="flex gap-3 justify-end">
              <div className="bg-emerald text-background rounded-sm px-4 py-3 max-w-md font-body">
                Best chance to see Nile lechwe this week?
              </div>
            </div>
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-full gradient-gold shrink-0 grid place-items-center"><Sparkles className="w-4 h-4 text-ink" /></div>
              <div className="bg-secondary rounded-sm px-4 py-3 max-w-xl font-body text-foreground">
                <p>Three lechwe pods are currently active in the Duma floodplain — a small herd of 14 was logged at <span className="font-mono text-clay">06:42 EAT</span> near sensor cluster D-07.</p>
                <p className="mt-3">Conditions are excellent for the next 36 hours. I recommend the dawn boat route from Itang, paired with our certified Anuak guide Okello.</p>
                <div className="mt-4 grid grid-cols-3 gap-2 font-mono text-[10px] uppercase tracking-widest">
                  <div className="border border-border p-2 rounded-sm"><div className="text-muted-foreground">Confidence</div><div className="text-emerald text-base mt-1">High</div></div>
                  <div className="border border-border p-2 rounded-sm"><div className="text-muted-foreground">Distance</div><div className="text-foreground text-base mt-1">22 km</div></div>
                  <div className="border border-border p-2 rounded-sm"><div className="text-muted-foreground">Window</div><div className="text-foreground text-base mt-1">36 h</div></div>
                </div>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-full gradient-gold shrink-0 grid place-items-center"><Sparkles className="w-4 h-4 text-ink" /></div>
              <div className="text-muted-foreground italic font-body">typing<span className="animate-pulse">...</span></div>
            </div>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-3 gap-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
          <span className="border border-border p-2 rounded-sm">Computer vision · 4 species/sec</span>
          <span className="border border-border p-2 rounded-sm">12k ranger reports indexed</span>
          <span className="border border-border p-2 rounded-sm">4 languages</span>
        </div>
      </div>
    </div>
  </section>
);

const Journeys = () => {
  const trips = [
    { name: "The Great Migration", days: "7 days", price: "$3,400", img: migrationImg, tag: "Signature", desc: "Witness 1.2M kob crossing the Akobo plains. Helicopter survey + ground tracking." },
    { name: "Wetland Whispers", days: "5 days", price: "$2,100", img: shoebillImg, tag: "Birding", desc: "Dawn boat expeditions through the Baro papyrus in search of the shoebill stork." },
    { name: "Conservationist Residency", days: "14 days", price: "$5,800", img: lechweImg, tag: "Immersive", desc: "Embed with Ethiopian Wildlife Authority rangers. Hands-on collaring, drone ops, community work." },
  ];
  return (
    <section id="journeys" className="relative py-24 lg:py-40 bg-secondary">
      <div className="max-w-[1600px] mx-auto px-6 lg:px-12">
        <div className="font-mono text-xs uppercase tracking-[0.25em] text-clay mb-6">— 04 / Journeys</div>
        <h2 className="font-display font-light text-foreground text-5xl lg:text-7xl leading-[0.95] tracking-tight text-balance max-w-4xl mb-16">
          Curated expeditions, <span className="italic text-emerald">small footprints</span>, deep impact.
        </h2>

        <div className="grid lg:grid-cols-3 gap-6">
          {trips.map((t, i) => (
            <article key={t.name} className="group bg-background rounded-sm overflow-hidden border border-border hover:shadow-elegant transition-all duration-500">
              <div className="relative aspect-[4/3] overflow-hidden">
                <img src={t.img} alt={t.name} loading="lazy" width={800} height={600}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" />
                <span className="absolute top-4 left-4 bg-background/90 backdrop-blur px-3 py-1 font-mono text-[10px] uppercase tracking-widest text-foreground rounded-sm">{t.tag}</span>
              </div>
              <div className="p-7">
                <div className="flex items-center justify-between font-mono text-[10px] uppercase tracking-widest text-muted-foreground mb-4">
                  <span>0{i + 1} / 03</span>
                  <span>{t.days}</span>
                </div>
                <h3 className="font-display text-3xl text-foreground tracking-tight">{t.name}</h3>
                <p className="mt-3 text-muted-foreground text-sm leading-relaxed">{t.desc}</p>
                <div className="mt-6 flex items-center justify-between pt-6 border-t border-border">
                  <div>
                    <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">From</div>
                    <div className="font-display text-2xl text-foreground">{t.price}</div>
                  </div>
                  <BookingDialog journeyName={t.name} price={t.price} />
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

const Conservation = () => (
  <section id="conserve" className="relative py-24 lg:py-40 bg-emerald text-background overflow-hidden">
    <div className="absolute inset-0 grain" />
    <div className="relative max-w-[1600px] mx-auto px-6 lg:px-12 grid lg:grid-cols-12 gap-12">
      <div className="lg:col-span-6">
        <div className="font-mono text-xs uppercase tracking-[0.25em] text-gold mb-6">— 05 / Conservation</div>
        <h2 className="font-display font-light text-5xl lg:text-7xl leading-[0.95] tracking-tight text-balance">
          Every visit funds a <span className="italic text-gold">ranger's day</span> in the field.
        </h2>
        <p className="mt-8 max-w-lg font-body text-background/70 text-lg leading-relaxed">
          We partner with the Ethiopian Wildlife Conservation Authority, Anuak and Nuer communities, and global research bodies. 100% of our conservation surcharge is published on-chain — fully transparent, fully traceable.
        </p>
        <Button variant="hero" size="lg" className="mt-10">View impact ledger <ArrowUpRight className="w-4 h-4" /></Button>
      </div>
      <div className="lg:col-span-6 grid grid-cols-2 gap-px bg-white/10">
        {[
          ["$2.4M", "deployed in 2025"],
          ["186", "rangers equipped"],
          ["43", "schools supported"],
          ["12,000", "hectares restored"],
        ].map(([k, v]) => (
          <div key={v} className="bg-emerald p-8 lg:p-12">
            <div className="font-display text-5xl lg:text-7xl font-light tracking-tighter text-gold">{k}</div>
            <div className="font-mono text-[10px] uppercase tracking-widest text-background/60 mt-4">{v}</div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

const Footer = () => (
  <footer className="bg-ink text-background/70 py-20">
    <div className="max-w-[1600px] mx-auto px-6 lg:px-12">
      <div className="grid lg:grid-cols-12 gap-12 pb-16 border-b border-white/10">
        <div className="lg:col-span-5">
          <div className="flex items-center gap-3 text-background mb-6">
            <div className="w-8 h-8 rounded-full gradient-gold grid place-items-center"><Leaf className="w-4 h-4 text-ink" /></div>
            <span className="font-display text-xl">Gambella<span className="text-gold">.</span></span>
          </div>
          <p className="max-w-md text-sm leading-relaxed">
            Ethiopia's last great wilderness, opened gently to those who will help defend it.
          </p>
          <div className="mt-6">
            <div className="font-mono text-[10px] uppercase tracking-widest text-gold mb-3">— Field journal</div>
            <NewsletterForm />
          </div>
          <div className="mt-8 flex items-center gap-2 text-xs font-mono uppercase tracking-widest">
            <MapPin className="w-3 h-3 text-gold" /> Gambella Region · Ethiopia · 8°15′N 34°35′E
          </div>
        </div>
        <div className="lg:col-span-7 grid grid-cols-2 md:grid-cols-4 gap-8 text-sm">
          {[
            ["Explore", ["The Wild", "Live Park", "AI Ranger", "Journeys"]],
            ["Conserve", ["Donate", "Volunteer", "Research", "Impact ledger"]],
            ["Visit", ["Plan a trip", "Permits", "Lodging", "FAQ"]],
            ["About", ["Authority", "Communities", "Press", "Contact"]],
          ].map(([h, items]) => (
            <div key={h as string}>
              <div className="font-mono text-[10px] uppercase tracking-widest text-gold mb-4">{h}</div>
              <ul className="space-y-2">{(items as string[]).map(i => <li key={i}><a href="#" className="hover:text-gold transition-colors">{i}</a></li>)}</ul>
            </div>
          ))}
        </div>
      </div>
      <div className="pt-8 flex flex-wrap justify-between gap-4 font-mono text-[10px] uppercase tracking-widest text-background/40">
        <span>© 2026 Gambella National Park · Ethiopian Wildlife Conservation Authority</span>
        <span>Designed for the wild · Built with Lovable</span>
      </div>
    </div>
  </footer>
);

const Index = () => (
  <main className="bg-background">
    <Nav />
    <Hero />
    <LiveTicker />
    <WildSection />
    <LiveDashboard />
    <AISection />
    <Journeys />
    <Conservation />
    <Footer />
  </main>
);

export default Index;
