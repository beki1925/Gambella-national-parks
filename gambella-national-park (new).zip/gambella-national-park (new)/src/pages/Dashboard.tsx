import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Leaf, ArrowLeft, Calendar, Users, Mail, Trash2, Pencil, LogOut } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "@/hooks/use-toast";

type Booking = {
  id: string;
  journey_name: string;
  start_date: string;
  party_size: number;
  contact_email: string;
  status: string;
  notes: string | null;
  created_at: string;
};

const statusVariant = (s: string) => {
  switch (s) {
    case "confirmed": return "bg-emerald/20 text-emerald border-emerald/40";
    case "cancelled": return "bg-clay/20 text-clay border-clay/40";
    default: return "bg-gold/20 text-gold border-gold/40";
  }
};

const Dashboard = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [userEmail, setUserEmail] = useState<string>("");
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [editing, setEditing] = useState<Booking | null>(null);
  const [deleting, setDeleting] = useState<Booking | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      if (!session) navigate("/auth", { replace: true });
    });
    supabase.auth.getSession().then(({ data }) => {
      if (!data.session) {
        navigate("/auth", { replace: true });
        return;
      }
      setUserEmail(data.session.user.email ?? "");
      loadBookings();
    });
    return () => sub.subscription.unsubscribe();
  }, [navigate]);

  const loadBookings = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("bookings")
      .select("*")
      .order("start_date", { ascending: true });
    if (error) {
      toast({ title: "Could not load reservations", description: error.message, variant: "destructive" });
    } else {
      setBookings((data ?? []) as Booking[]);
    }
    setLoading(false);
  };

  const saveEdit = async () => {
    if (!editing) return;
    setSaving(true);
    const { error } = await supabase
      .from("bookings")
      .update({
        journey_name: editing.journey_name,
        start_date: editing.start_date,
        party_size: editing.party_size,
        contact_email: editing.contact_email,
        notes: editing.notes,
      })
      .eq("id", editing.id);
    setSaving(false);
    if (error) {
      toast({ title: "Update failed", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Reservation updated" });
    setEditing(null);
    loadBookings();
  };

  const cancelBooking = async (b: Booking) => {
    const { error } = await supabase
      .from("bookings")
      .update({ status: "cancelled" })
      .eq("id", b.id);
    if (error) {
      toast({ title: "Could not cancel", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Reservation cancelled" });
    loadBookings();
  };

  const deleteBooking = async () => {
    if (!deleting) return;
    const { error } = await supabase.from("bookings").delete().eq("id", deleting.id);
    setDeleting(null);
    if (error) {
      toast({ title: "Delete failed", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Reservation removed" });
    loadBookings();
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    navigate("/", { replace: true });
  };

  const upcoming = bookings.filter(b => new Date(b.start_date) >= new Date(new Date().toDateString()) && b.status !== "cancelled");
  const past = bookings.filter(b => !upcoming.includes(b));

  return (
    <main className="min-h-screen bg-ink text-background">
      <header className="border-b border-white/10 sticky top-0 z-30 backdrop-blur bg-ink/80">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full gradient-gold grid place-items-center">
              <Leaf className="w-4 h-4 text-ink" />
            </div>
            <span className="font-display text-lg">Gambella<span className="text-gold">.</span></span>
          </Link>
          <div className="flex items-center gap-2">
            <Button variant="ghostLight" size="sm" asChild>
              <Link to="/"><ArrowLeft className="w-4 h-4" /> Park</Link>
            </Button>
            <Button variant="ghostLight" size="sm" onClick={signOut}>
              <LogOut className="w-4 h-4" /> Sign out
            </Button>
          </div>
        </div>
      </header>

      <section className="max-w-6xl mx-auto px-6 py-16">
        <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-gold mb-3">— Visitor dashboard</p>
        <h1 className="font-display text-5xl md:text-6xl font-light tracking-tight">
          Your <span className="italic text-gold">expeditions</span>
        </h1>
        <p className="text-background/60 mt-3 font-mono text-xs">
          Signed in as {userEmail}
        </p>

        <div className="grid sm:grid-cols-3 gap-4 mt-10">
          <Card className="bg-white/5 border-white/10 text-background">
            <CardHeader className="pb-2"><CardDescription className="text-background/60 font-mono text-[10px] uppercase tracking-widest">Upcoming</CardDescription></CardHeader>
            <CardContent><div className="font-display text-4xl">{upcoming.length}</div></CardContent>
          </Card>
          <Card className="bg-white/5 border-white/10 text-background">
            <CardHeader className="pb-2"><CardDescription className="text-background/60 font-mono text-[10px] uppercase tracking-widest">Total</CardDescription></CardHeader>
            <CardContent><div className="font-display text-4xl">{bookings.length}</div></CardContent>
          </Card>
          <Card className="bg-white/5 border-white/10 text-background">
            <CardHeader className="pb-2"><CardDescription className="text-background/60 font-mono text-[10px] uppercase tracking-widest">Travelers</CardDescription></CardHeader>
            <CardContent><div className="font-display text-4xl">{bookings.reduce((s, b) => s + b.party_size, 0)}</div></CardContent>
          </Card>
        </div>

        <div className="mt-14">
          <h2 className="font-display text-2xl mb-4">Upcoming reservations</h2>
          {loading ? (
            <p className="text-background/50 font-mono text-xs">Loading…</p>
          ) : upcoming.length === 0 ? (
            <Card className="bg-white/5 border-white/10 text-background p-10 text-center">
              <p className="text-background/60">No upcoming expeditions yet.</p>
              <Button asChild variant="hero" className="mt-4"><Link to="/">Browse journeys</Link></Button>
            </Card>
          ) : (
            <div className="grid gap-4">
              {upcoming.map(b => (
                <BookingCard key={b.id} b={b} onEdit={setEditing} onCancel={cancelBooking} onDelete={setDeleting} />
              ))}
            </div>
          )}

          {past.length > 0 && (
            <>
              <h2 className="font-display text-2xl mt-14 mb-4">History</h2>
              <div className="grid gap-4 opacity-70">
                {past.map(b => (
                  <BookingCard key={b.id} b={b} onEdit={setEditing} onCancel={cancelBooking} onDelete={setDeleting} />
                ))}
              </div>
            </>
          )}
        </div>
      </section>

      <Dialog open={!!editing} onOpenChange={o => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit reservation</DialogTitle>
            <DialogDescription>Update your expedition details.</DialogDescription>
          </DialogHeader>
          {editing && (
            <div className="grid gap-4">
              <div className="space-y-2">
                <Label>Journey</Label>
                <Input value={editing.journey_name} onChange={e => setEditing({ ...editing, journey_name: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>Start date</Label>
                  <Input type="date" value={editing.start_date} onChange={e => setEditing({ ...editing, start_date: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label>Party size</Label>
                  <Input type="number" min={1} value={editing.party_size} onChange={e => setEditing({ ...editing, party_size: Number(e.target.value) })} />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Contact email</Label>
                <Input type="email" value={editing.contact_email} onChange={e => setEditing({ ...editing, contact_email: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Notes</Label>
                <Input value={editing.notes ?? ""} onChange={e => setEditing({ ...editing, notes: e.target.value })} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
            <Button variant="emerald" onClick={saveEdit} disabled={saving}>{saving ? "Saving…" : "Save changes"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove this reservation?</AlertDialogTitle>
            <AlertDialogDescription>This permanently deletes the booking record.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep</AlertDialogCancel>
            <AlertDialogAction onClick={deleteBooking}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </main>
  );
};

const BookingCard = ({
  b, onEdit, onCancel, onDelete,
}: {
  b: Booking;
  onEdit: (b: Booking) => void;
  onCancel: (b: Booking) => void;
  onDelete: (b: Booking) => void;
}) => (
  <Card className="bg-white/5 border-white/10 text-background">
    <CardContent className="p-6 flex flex-col md:flex-row md:items-center gap-6 justify-between">
      <div className="flex-1">
        <div className="flex items-center gap-3 mb-2">
          <CardTitle className="font-display text-xl">{b.journey_name}</CardTitle>
          <Badge variant="outline" className={statusVariant(b.status)}>{b.status}</Badge>
        </div>
        <div className="flex flex-wrap gap-4 text-xs font-mono text-background/60">
          <span className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" /> {new Date(b.start_date).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" })}</span>
          <span className="flex items-center gap-1.5"><Users className="w-3.5 h-3.5" /> {b.party_size} traveler{b.party_size > 1 ? "s" : ""}</span>
          <span className="flex items-center gap-1.5"><Mail className="w-3.5 h-3.5" /> {b.contact_email}</span>
        </div>
        {b.notes && <p className="text-sm text-background/70 mt-3">{b.notes}</p>}
      </div>
      <div className="flex gap-2">
        <Button variant="ghostLight" size="sm" onClick={() => onEdit(b)}><Pencil className="w-3.5 h-3.5" /> Edit</Button>
        {b.status !== "cancelled" && (
          <Button variant="ghostLight" size="sm" onClick={() => onCancel(b)}>Cancel</Button>
        )}
        <Button variant="ghostLight" size="sm" onClick={() => onDelete(b)}><Trash2 className="w-3.5 h-3.5" /></Button>
      </div>
    </CardContent>
  </Card>
);

export default Dashboard;
