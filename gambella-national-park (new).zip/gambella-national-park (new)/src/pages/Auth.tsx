import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Leaf, ArrowUpRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";

const Auth = () => {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate("/", { replace: true });
    });
  }, [navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const redirectUrl = `${window.location.origin}/`;
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: redirectUrl, data: { full_name: fullName } },
        });
        if (error) throw error;
        toast({ title: "Welcome to Gambella", description: "Check your inbox to verify your email." });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate("/", { replace: true });
      }
    } catch (err: any) {
      toast({ title: "Authentication failed", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen grid lg:grid-cols-2 bg-ink text-background">
      <div className="relative hidden lg:block overflow-hidden">
        <div className="absolute inset-0 bg-[url('/src/assets/hero-gambella.jpg')] bg-cover bg-center scale-105" />
        <div className="absolute inset-0 bg-gradient-to-tr from-ink via-ink/60 to-transparent" />
        <div className="relative h-full p-12 flex flex-col justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full gradient-gold grid place-items-center"><Leaf className="w-4 h-4 text-ink" /></div>
            <span className="font-display text-lg">Gambella<span className="text-gold">.</span></span>
          </Link>
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-gold mb-4">— Members only</p>
            <h1 className="font-display text-5xl font-light leading-[0.95] tracking-tight max-w-md">
              The wild remembers <span className="italic text-gold">those who return</span>.
            </h1>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center p-8">
        <form onSubmit={submit} className="w-full max-w-sm space-y-6">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-gold mb-3">— {mode === "signin" ? "Sign in" : "Create account"}</p>
            <h2 className="font-display text-4xl font-light tracking-tight">{mode === "signin" ? "Welcome back" : "Join the expedition"}</h2>
          </div>

          {mode === "signup" && (
            <div className="space-y-2">
              <Label htmlFor="name" className="font-mono text-[10px] uppercase tracking-widest text-background/60">Full name</Label>
              <Input id="name" value={fullName} onChange={e => setFullName(e.target.value)} required
                className="bg-transparent border-white/20 text-background" />
            </div>
          )}
          <div className="space-y-2">
            <Label htmlFor="email" className="font-mono text-[10px] uppercase tracking-widest text-background/60">Email</Label>
            <Input id="email" type="email" value={email} onChange={e => setEmail(e.target.value)} required
              className="bg-transparent border-white/20 text-background" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password" className="font-mono text-[10px] uppercase tracking-widest text-background/60">Password</Label>
            <Input id="password" type="password" value={password} onChange={e => setPassword(e.target.value)} required minLength={6}
              className="bg-transparent border-white/20 text-background" />
          </div>

          <Button type="submit" variant="hero" className="w-full" disabled={loading}>
            {loading ? "Working…" : mode === "signin" ? "Sign in" : "Create account"} <ArrowUpRight className="w-4 h-4" />
          </Button>

          <button type="button" onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
            className="w-full text-center font-mono text-[10px] uppercase tracking-widest text-background/60 hover:text-gold">
            {mode === "signin" ? "No account? Create one" : "Have an account? Sign in"}
          </button>
        </form>
      </div>
    </main>
  );
};

export default Auth;
