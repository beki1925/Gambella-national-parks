import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";

interface Props {
  journeyName: string;
  price: string;
  trigger?: React.ReactNode;
}

export const BookingDialog = ({ journeyName, price, trigger }: Props) => {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [date, setDate] = useState("");
  const [partySize, setPartySize] = useState(2);
  const [email, setEmail] = useState("");
  const [notes, setNotes] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data: sess } = await supabase.auth.getSession();
      if (!sess.session) {
        toast({ title: "Sign in required", description: "Create an account to reserve an expedition." });
        setOpen(false);
        navigate("/auth");
        return;
      }
      const { error } = await supabase.from("bookings").insert({
        user_id: sess.session.user.id,
        journey_name: journeyName,
        start_date: date,
        party_size: partySize,
        contact_email: email,
        notes,
      });
      if (error) throw error;
      toast({ title: "Reservation requested", description: `Our concierge will confirm ${journeyName} shortly.` });
      setOpen(false);
    } catch (err: any) {
      toast({ title: "Could not reserve", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? <Button variant="emerald" size="sm">Reserve <ArrowUpRight className="w-4 h-4" /></Button>}
      </DialogTrigger>
      <DialogContent className="bg-background">
        <DialogHeader>
          <DialogTitle className="font-display text-3xl font-light">{journeyName}</DialogTitle>
          <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">From {price} · per traveller</p>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4 pt-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date" className="font-mono text-[10px] uppercase tracking-widest">Start date</Label>
              <Input id="date" type="date" required value={date} onChange={e => setDate(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="party" className="font-mono text-[10px] uppercase tracking-widest">Party size</Label>
              <Input id="party" type="number" min={1} max={20} required value={partySize}
                onChange={e => setPartySize(Number(e.target.value))} />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="email" className="font-mono text-[10px] uppercase tracking-widest">Contact email</Label>
            <Input id="email" type="email" required value={email} onChange={e => setEmail(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="notes" className="font-mono text-[10px] uppercase tracking-widest">Notes (optional)</Label>
            <Textarea id="notes" value={notes} onChange={e => setNotes(e.target.value)} rows={3}
              placeholder="Dietary needs, mobility, special interests…" />
          </div>
          <Button type="submit" variant="emerald" className="w-full" disabled={loading}>
            {loading ? "Reserving…" : "Request reservation"} <ArrowUpRight className="w-4 h-4" />
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};
