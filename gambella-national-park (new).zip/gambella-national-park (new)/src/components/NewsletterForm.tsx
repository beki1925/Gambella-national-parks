import { useState } from "react";
import { ArrowUpRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";

export const NewsletterForm = () => {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.from("newsletter_subscribers").insert({ email });
    setLoading(false);
    if (error) {
      const msg = error.code === "23505" ? "You're already on the list." : error.message;
      toast({ title: "Subscription failed", description: msg, variant: "destructive" });
      return;
    }
    setEmail("");
    toast({ title: "Welcome to the field journal", description: "Dispatches from the wild, twice a month." });
  };

  return (
    <form onSubmit={submit} className="flex gap-2 max-w-sm">
      <Input type="email" required value={email} onChange={e => setEmail(e.target.value)}
        placeholder="your@email.com"
        className="bg-transparent border-white/20 text-background placeholder:text-background/40" />
      <Button type="submit" variant="hero" size="sm" disabled={loading}>
        {loading ? "…" : <>Join <ArrowUpRight className="w-4 h-4" /></>}
      </Button>
    </form>
  );
};
