CREATE OR REPLACE FUNCTION public.claim_admin_if_none()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  has_any boolean;
BEGIN
  IF uid IS NULL THEN RETURN false; END IF;
  SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE role = 'admin') INTO has_any;
  IF has_any THEN RETURN false; END IF;
  INSERT INTO public.user_roles (user_id, role) VALUES (uid, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  RETURN true;
END;
$$;

-- Allow admins to delete bookings/sightings via existing ALL policies; add DELETE policy for sightings (admins)
CREATE POLICY "Admins delete sightings" ON public.sightings
  FOR DELETE USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins delete subscribers" ON public.newsletter_subscribers
  FOR DELETE USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins update subscribers" ON public.newsletter_subscribers
  FOR UPDATE USING (has_role(auth.uid(), 'admin'));